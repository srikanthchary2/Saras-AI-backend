<?php

namespace Modules\SarasAI\Database\Seeders;

use Illuminate\Database\Seeder;

class SarasAIDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
