<?php

return [
    'name' => 'Student',
];
