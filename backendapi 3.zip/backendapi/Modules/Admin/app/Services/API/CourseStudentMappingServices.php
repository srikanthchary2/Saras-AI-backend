<?php

namespace Modules\Admin\Services\API;

class CourseStudentMappingServices
{
    public function handle()
    {
        //
    }
}
