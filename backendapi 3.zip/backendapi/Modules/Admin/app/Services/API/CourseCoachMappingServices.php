<?php

namespace Modules\Admin\Services\API;

class CourseCoachMappingServices
{
    public function handle()
    {
        //
    }
}
