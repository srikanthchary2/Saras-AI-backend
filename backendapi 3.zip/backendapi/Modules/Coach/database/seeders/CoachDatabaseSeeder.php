<?php

namespace Modules\Coach\Database\Seeders;

use Illuminate\Database\Seeder;

class CoachDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
