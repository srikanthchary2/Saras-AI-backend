<?php

return [
    'name' => 'AuthService',
];
