<?php

namespace Modules\AuthService\Database\Seeders;

use Illuminate\Database\Seeder;

class AuthServiceDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
