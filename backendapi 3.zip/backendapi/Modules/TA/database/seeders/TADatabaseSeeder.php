<?php

namespace Modules\TA\Database\Seeders;

use Illuminate\Database\Seeder;

class TADatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
