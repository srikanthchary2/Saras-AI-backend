<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Student\\Providers\\StudentServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Student\\Providers\\StudentServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);